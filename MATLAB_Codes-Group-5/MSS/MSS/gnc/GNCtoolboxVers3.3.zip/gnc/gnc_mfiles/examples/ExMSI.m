% ExMSI Plots the ISO 2631-1 (1997) and O'Hanlon and McCauley (1974)
%       Motion Sickness Incidence curves
%
% Author:    Thor I. Fossen
% Date:      5th November 2001
% Revisions: 
% ________________________________________________________________
%
% MSS GNC is a Matlab toolbox for guidance, navigation and control.
% The toolbox is part of the Marine Systems Simulator (MSS).
%
% Copyright (C) 2008 Thor I. Fossen and Tristan Perez
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
% 
% E-mail: contact@marinecontrol.org
% URL:    <http://www.marinecontrol.org>

clf
conversion       % load conversion factors

%---------------------------------------------------------------------------
% Plot O'Hanlon and McCauley MSI
%---------------------------------------------------------------------------

w_0 = 0.01:0.1:2;  % wave frequency (rad/s)
U = 15;            % vessel speed (m/s)
beta = 180*D2R;    % wave encounter angle (rad)

a_z = [0.5 1 2 3 4 5]; % vertical accelerations (m/s^2)
idx = ['x','o','d','h','s','v'];

figure(1); hold on
for i = 1:6,
    w_e = encounter(w_0,U,beta);           % frequency of encounter (rad/s)
    msi = HMmsi(a_z(i),w_e);               % O'Hanlon and McCauley MSI (%)
    h=plot(w_e,msi,'b',w_e,msi,idx(i));    % plot curve
    hh(i)=h(2);                            % figure handle
end

hold off
title('O''Hanlon and McCauley (1974) Motion Sickness Incidence (MSI)')
xlabel('Frequency of encounter \omega_e (rad/s)')
ylabel('MSI (%)')
legend(hh,'a_z = 0.5 (m/s^2)','a_z  = 1 (m/s^2)','a_z  = 2 (m/s^2)','a_z  = 3 (m/s^2)',...
    'a_z  = 4 (m/s^2)','a_z  = 5 (m/s^2)');
grid

%---------------------------------------------------------------------------
% Plot ISO MSI
%---------------------------------------------------------------------------
clear all


t = [0.5 1 2 4 8];
idx = ['^','*','d','s','o'];
figure(2); hold on

for i = 1:5,
    [a_z,w_e] = ISOmsi(t(i));              % ISO 2631 MSI
    h = plot(w_e,a_z,'b',w_e,a_z,idx(i));  % plot curve
    hh(i)=h(2);                            % figure handle
end

hold off
title('ISO 2631 Motion Sickness Incidence (MSI)')
xlabel('Frequency of encounter \omega_e (rad/s)')
ylabel('a_z (m/s^2)')
legend(hh,'ISO 30 MIN','ISO 1 HR','ISO 2 HRS','ISO 4 HRS','ISO 8 HRS')
grid

